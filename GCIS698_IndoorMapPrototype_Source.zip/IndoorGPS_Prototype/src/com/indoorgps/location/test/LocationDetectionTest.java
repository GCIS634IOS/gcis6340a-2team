package com.indoorgps.location.test;


import junit.framework.TestCase;
import android.test.suitebuilder.annotation.SmallTest;

import com.example.indoorgps_prototype.FingerprintMatching;


public class LocationDetectionTest extends TestCase {

	
	@SmallTest
	public void testDetection(){
	
	}
}
